"""AntForaging: a small partial-observability Gymnasium env."""
from gymnasium.envs.registration import register

from .env import (
    AntForagingEnv,
    AntForagingConfig,
    EMPTY, WALL, FOOD, ANT,
    ACTION_UP, ACTION_RIGHT, ACTION_DOWN, ACTION_LEFT,
)

register(
    id="AntForaging-v0",
    entry_point="ant_foraging.env:AntForagingEnv",
)

__all__ = [
    "AntForagingEnv",
    "AntForagingConfig",
    "EMPTY", "WALL", "FOOD", "ANT",
    "ACTION_UP", "ACTION_RIGHT", "ACTION_DOWN", "ACTION_LEFT",
]
