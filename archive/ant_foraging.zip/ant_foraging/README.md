# AntForaging — a Gymnasium env

A small partial-observability foraging environment. An ant lives on a 2D grid
that contains walls and food. It can see only within `sight_radius` cells of
itself. Eat all the food, don't bonk into walls.

## Install

```bash
cd ant_foraging
pip install -e .
```

## Quick start

```python
import gymnasium as gym
import ant_foraging  # registers the env

env = gym.make("AntForaging-v0")  # or AntForagingEnv(config) directly
obs, info = env.reset(seed=0)
obs, reward, terminated, truncated, info = env.step(env.action_space.sample())
```

## Configuration

`AntForagingConfig` is a `dataclass` that fully describes an env. You can
pass it to `AntForagingEnv(config)` or convert it to/from a `dict` with
`to_dict()` / `from_dict()` so configs are *portable* — pickle, JSON, store
in a sweep, whatever.

| Field          | Default | Meaning                                                  |
|----------------|---------|----------------------------------------------------------|
| `width`        | 20      | Grid width                                               |
| `height`       | 20      | Grid height                                              |
| `sight_radius` | 3       | Egocentric view is `(2r+1) x (2r+1)`                     |
| `n_food`       | 5       | Number of food pellets when procedurally generating      |
| `wall_density` | 0.15    | Fraction of cells turned into walls during generation    |
| `ant_start`    | None    | `(x, y)` start, or `None` to pick a random empty cell    |
| `step_penalty` | -1.0    | Reward each step                                         |
| `food_reward`  | +50.0   | Bonus for stepping onto food                             |
| `wall_penalty` | -5.0    | Penalty for trying to move out of bounds or into a wall  |
| `max_steps`    | 500     | Episode truncation horizon                               |
| `grid`         | None    | Optional `list[list[int]]` map to use verbatim           |

### Pre-made map

```python
from ant_foraging import AntForagingEnv, AntForagingConfig, EMPTY, WALL, FOOD

grid = [
    [EMPTY, EMPTY, WALL,  EMPTY],
    [EMPTY, FOOD,  EMPTY, EMPTY],
    [WALL,  EMPTY, EMPTY, FOOD ],
]
cfg = AntForagingConfig(sight_radius=2, ant_start=(0, 0), grid=grid)
env = AntForagingEnv(cfg)
```

You can also pass `options={"grid": [...]}` to `env.reset()` for a one-off
map override without changing the config.

## Action / observation / reward

- **Actions** — `Discrete(4)`: `0=up, 1=right, 2=down, 3=left`.
- **Observation** — `Box(0, 3, shape=(2r+1, 2r+1), dtype=uint8)` egocentric
  window. Tile codes: `0=empty, 1=wall, 2=food, 3=ant`. Cells outside the
  map appear as walls.
- **Reward** — `step_penalty` each step, `+food_reward` when stepping onto
  food (which is then removed), `+wall_penalty` when attempting to move out
  of bounds or into a wall (the ant stays still).

## `info` dict

Every step returns:

- `food_eaten` — cumulative food consumed
- `distance_traveled` — cumulative successful moves
- `wall_hits` — cumulative out-of-bounds *or* wall-bump attempts
- `food_remaining`, `ant_pos`, `moved`, `ate_food`, `steps`

## Run the demo / tests

```bash
python demo.py
pytest -q
```
