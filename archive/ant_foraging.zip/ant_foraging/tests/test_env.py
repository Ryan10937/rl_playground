import numpy as np
import pytest
import gymnasium as gym

import ant_foraging  # noqa: F401  (registers env)
from ant_foraging import (
    AntForagingEnv, AntForagingConfig,
    EMPTY, WALL, FOOD, ANT,
    ACTION_UP, ACTION_RIGHT, ACTION_DOWN, ACTION_LEFT,
)


# ---------- basic API ----------------------------------------------------
def test_registered():
    env = gym.make("AntForaging-v0")
    obs, info = env.reset(seed=0)
    assert env.observation_space.contains(obs)
    env.close()


def test_obs_shape_and_center():
    cfg = AntForagingConfig(width=10, height=10, sight_radius=2, n_food=3, wall_density=0.1)
    env = AntForagingEnv(cfg)
    obs, _ = env.reset(seed=0)
    assert obs.shape == (5, 5)
    assert obs[2, 2] == ANT


def test_action_and_obs_spaces():
    cfg = AntForagingConfig(sight_radius=4)
    env = AntForagingEnv(cfg)
    assert env.action_space.n == 4
    assert env.observation_space.shape == (9, 9)


# ---------- determinism --------------------------------------------------
def test_seeding_is_reproducible():
    cfg = AntForagingConfig(width=12, height=12, sight_radius=2, n_food=4, wall_density=0.2)
    e1 = AntForagingEnv(cfg); e2 = AntForagingEnv(cfg)
    o1, _ = e1.reset(seed=42)
    o2, _ = e2.reset(seed=42)
    np.testing.assert_array_equal(o1, o2)
    np.testing.assert_array_equal(e1._grid, e2._grid)
    assert e1._ant_xy == e2._ant_xy


# ---------- rewards & info -----------------------------------------------
def test_step_penalty_only_on_empty_move():
    # Hand-crafted 3x3 with ant in the middle, all empty
    grid = [[EMPTY]*3 for _ in range(3)]
    cfg = AntForagingConfig(sight_radius=1, ant_start=(1, 1), grid=grid,
                            step_penalty=-1.0, food_reward=50.0, wall_penalty=-5.0,
                            max_steps=100)
    env = AntForagingEnv(cfg)
    env.reset(seed=0)
    obs, r, term, trunc, info = env.step(ACTION_RIGHT)
    assert r == -1.0
    assert info["moved"] is True
    assert info["distance_traveled"] == 1
    assert info["wall_hits"] == 0


def test_food_reward_and_consumption():
    grid = [[EMPTY, FOOD, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]
    cfg = AntForagingConfig(sight_radius=1, ant_start=(0, 0), grid=grid,
                            step_penalty=-1.0, food_reward=50.0, wall_penalty=-5.0)
    env = AntForagingEnv(cfg)
    env.reset(seed=0)
    _, r, term, _, info = env.step(ACTION_RIGHT)  # step onto food at (1,0)
    assert r == pytest.approx(-1.0 + 50.0)
    assert info["ate_food"] is True
    assert info["food_eaten"] == 1
    assert info["food_remaining"] == 0
    assert term is True   # only one food existed -> episode ends


def test_wall_penalty_out_of_bounds_keeps_ant_still():
    grid = [[EMPTY, EMPTY], [EMPTY, EMPTY]]
    cfg = AntForagingConfig(sight_radius=1, ant_start=(0, 0), grid=grid,
                            step_penalty=-1.0, food_reward=50.0, wall_penalty=-5.0,
                            max_steps=10)
    env = AntForagingEnv(cfg)
    env.reset(seed=0)
    _, r, _, _, info = env.step(ACTION_LEFT)  # would go to (-1, 0)
    assert r == pytest.approx(-6.0)
    assert info["wall_hits"] == 1
    assert info["distance_traveled"] == 0
    assert info["ant_pos"] == (0, 0)
    assert info["moved"] is False


def test_wall_penalty_hitting_wall_keeps_ant_still():
    grid = [[EMPTY, WALL], [EMPTY, EMPTY]]
    cfg = AntForagingConfig(sight_radius=1, ant_start=(0, 0), grid=grid,
                            step_penalty=-1.0, food_reward=50.0, wall_penalty=-5.0)
    env = AntForagingEnv(cfg)
    env.reset(seed=0)
    _, r, _, _, info = env.step(ACTION_RIGHT)
    assert r == pytest.approx(-6.0)
    assert info["wall_hits"] == 1
    assert info["ant_pos"] == (0, 0)


# ---------- observation correctness --------------------------------------
def test_offmap_cells_are_walls_in_observation():
    grid = [[EMPTY, EMPTY], [EMPTY, EMPTY]]
    cfg = AntForagingConfig(sight_radius=2, ant_start=(0, 0), grid=grid)
    env = AntForagingEnv(cfg)
    obs, _ = env.reset(seed=0)
    # Ant at (0,0), window is 5x5 centered there. Top two rows & left two cols
    # are off-map -> walls.
    assert (obs[0, :] == WALL).all()
    assert (obs[1, :] == WALL).all()
    assert (obs[:, 0] == WALL).all()
    assert (obs[:, 1] == WALL).all()
    assert obs[2, 2] == ANT


def test_termination_on_all_food_eaten():
    grid = [[EMPTY, FOOD]]
    cfg = AntForagingConfig(sight_radius=1, ant_start=(0, 0), grid=grid, max_steps=10)
    env = AntForagingEnv(cfg)
    env.reset(seed=0)
    _, _, term, trunc, info = env.step(ACTION_RIGHT)
    assert term and not trunc
    assert info["food_remaining"] == 0


def test_truncation_on_max_steps():
    grid = [[EMPTY, EMPTY], [EMPTY, FOOD]]  # food exists but we won't reach it
    cfg = AntForagingConfig(sight_radius=1, ant_start=(0, 0), grid=grid, max_steps=2)
    env = AntForagingEnv(cfg)
    env.reset(seed=0)
    env.step(ACTION_LEFT)   # wall hit, no move
    _, _, term, trunc, info = env.step(ACTION_LEFT)
    assert not term and trunc


# ---------- portable config ---------------------------------------------
def test_config_roundtrip_via_dict():
    cfg = AntForagingConfig(width=8, height=6, sight_radius=2, n_food=3, wall_density=0.1)
    d = cfg.to_dict()
    cfg2 = AntForagingConfig.from_dict(d)
    assert cfg2 == cfg
    env = AntForagingEnv(cfg2)
    env.reset(seed=1)


def test_options_grid_override_on_reset():
    # Start with random gen, but pass an explicit grid via options on reset.
    cfg = AntForagingConfig(width=5, height=5, sight_radius=1, n_food=2)
    env = AntForagingEnv(cfg)
    custom = [[EMPTY, FOOD, EMPTY],
              [EMPTY, EMPTY, EMPTY],
              [EMPTY, WALL, EMPTY]]
    obs, info = env.reset(seed=0, options={"grid": custom})
    assert env._grid.shape == (3, 3)
    assert info["food_remaining"] == 1


# ---------- rendering ----------------------------------------------------
def test_ansi_render():
    cfg = AntForagingConfig(width=5, height=5, sight_radius=1, n_food=2)
    env = AntForagingEnv(cfg, render_mode="ansi")
    env.reset(seed=0)
    s = env.render()
    assert isinstance(s, str)
    assert "A" in s
    assert len(s.splitlines()) == 5


def test_rgb_render_shape():
    cfg = AntForagingConfig(width=6, height=4, sight_radius=1, n_food=1)
    env = AntForagingEnv(cfg, render_mode="rgb_array")
    env.reset(seed=0)
    img = env.render()
    assert img.shape == (4, 6, 3)
    assert img.dtype == np.uint8
