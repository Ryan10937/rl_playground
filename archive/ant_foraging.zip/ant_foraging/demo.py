"""Random-policy rollout demo for AntForagingEnv."""
import numpy as np
from ant_foraging import AntForagingEnv, AntForagingConfig


def main():
    cfg = AntForagingConfig(
        width=15, height=10, sight_radius=2,
        n_food=6, wall_density=0.18,
        step_penalty=-1.0, food_reward=50.0, wall_penalty=-5.0,
        max_steps=200,
    )
    env = AntForagingEnv(cfg, render_mode="ansi")
    obs, info = env.reset(seed=7)

    print("Initial map:")
    print(env.render())
    print("Initial 5x5 egocentric obs (0=empty 1=wall 2=food 3=ant):")
    print(obs)
    print()

    rng = np.random.default_rng(7)
    total_reward = 0.0
    for t in range(cfg.max_steps):
        a = int(rng.integers(4))
        obs, r, term, trunc, info = env.step(a)
        total_reward += r
        if term or trunc:
            break

    print("Final map:")
    print(env.render())
    print()
    print(f"Steps:              {info['steps']}")
    print(f"Total reward:       {total_reward:.1f}")
    print(f"Food eaten:         {info['food_eaten']}")
    print(f"Distance traveled:  {info['distance_traveled']}")
    print(f"Wall hits:          {info['wall_hits']}")
    print(f"Food remaining:     {info['food_remaining']}")
    print(f"Terminated/Truncated: {term}/{trunc}")


if __name__ == "__main__":
    main()
